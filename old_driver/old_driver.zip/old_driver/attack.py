from glob import glob
import torch
from torch import nn, optim
import torch.nn.functional as F
import torchattacks # https://github.com/Harry24k/adversarial-attacks-pytorch
from torchvision import transforms
from PIL import Image
import random
import os
from hashlib import md5, sha256

class Model(nn.Module):
    def __init__(self):
        super(Model, self).__init__()
        self.conv1 = nn.Conv2d(3, 100, 5)
        self.conv1_bn = nn.BatchNorm2d(100)
        self.pool = nn.MaxPool2d(2, 2)
        self.conv2 = nn.Conv2d(100, 150, 3)
        self.conv2_bn = nn.BatchNorm2d(150)
        self.conv3 = nn.Conv2d(150, 250, 1)
        self.conv3_bn = nn.BatchNorm2d(250)
        self.fc1 = nn.Linear(250 * 3 * 3, 350)
        self.fc1_bn = nn.BatchNorm1d(350)
        self.fc2 = nn.Linear(350, 10)
        self.dropout = nn.Dropout(p=0.5)

    def forward(self, x):
        x = self.pool(F.elu(self.conv1(x)))
        x = self.dropout(self.conv1_bn(x))
        x = self.pool(F.elu(self.conv2(x)))
        x = self.dropout(self.conv2_bn(x))
        x = self.pool(F.elu(self.conv3(x)))
        x = self.dropout(self.conv3_bn(x))
        x = x.view(-1, 250 * 3 * 3)
        x = F.elu(self.fc1(x))
        x = self.dropout(self.fc1_bn(x))
        x = self.fc2(x)
        return x


# load pretrained model
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
transform = transforms.ToTensor()
model = Model().to(device)
check_point = torch.load('model.pt', map_location=device)
model.load_state_dict(check_point)
model.eval()

# untargeted CW attack
atk = torchattacks.CW(model, c=1, kappa=0.3)

# generate an adversarial example for each class
pairs = []
for cl in range(10):
    while True:
        origin_image = random.choice(glob(f'test/{cl}/*.png'))
        image = transform(Image.open(origin_image)).to(device)[None, ...]
        label = torch.tensor(cl, device=device)
        adv_image = atk(image, label)
        origin_output = model(image)
        adv_output = model(adv_image)
        origin_label = torch.argmax(origin_output, axis=1).item()
        adv_label = torch.argmax(adv_output, axis=1).item()
        if adv_label == origin_label:
            continue
        transforms.ToPILImage()(adv_image[0]).save(f'adv_{origin_label}_{adv_label}.png')

        # confirm that the generated adversarial example is working
        image = transform(Image.open(f'adv_{origin_label}_{adv_label}.png')).to(device)[None, ...]
        output = model(image)
        if torch.argmax(output, axis=1).item() != adv_label:
            continue
        pairs.append((origin_image, f'adv_{origin_label}_{adv_label}.png', origin_label, adv_label))
        break

# remove origin images and move adversarial examples into target classes
for origin_fname, adv_fname, origin_label, adv_label in pairs:
    os.rename(adv_fname, f'test/{adv_label}/{adv_fname}')
    os.remove(origin_fname)

# shuffle all the images to hide adversarial examples
os.mkdir('imgs')
adversarial_images = []
for cl in range(10):
    images = glob(f'test/{cl}/*.png')
    os.mkdir(f'imgs/{cl}')
    random.shuffle(images)
    for idx, image in enumerate(images):
        os.rename(image, f'imgs/{cl}/{idx}.png')
        if 'adv' in image:
            adversarial_images.append(idx)

# You can get the flag if you find all the adversarial examples :)
flag = 'flag{' + md5(str(sorted(adversarial_images)).encode()).hexdigest() + '}'

# Give you some hints though you can solve this challenge without them
hint1 = [(row[2], row[3]) for row in pairs]
hint2 = sha256(str(sorted(adversarial_images)).encode()).hexdigest()

print('flag:', flag)
print('hint1:', hint1)
print('hint2:', hint2)

# flag: flag{*********REDACTED**********}
# hint1: [(0, 1), (1, 0), (2, 6), (3, 4), (4, 3), (5, 6), (6, 5), (7, 8), (8, 7), (9, 1)]
# hint2: 502e0423b82c251f280e4c3261ee4d01dca4f6fe0b663817e9fd43dffefc5ce9